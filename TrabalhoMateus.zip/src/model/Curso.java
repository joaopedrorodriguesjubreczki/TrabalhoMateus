// Classe Curso
package model;

import java.util.*;

public class Curso {
    private String nome;
    private int cargaHoraria;
    private List<Disciplina> disciplinas = new ArrayList<>();

    public Curso(String nome, int cargaHoraria) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
    }

    public String getNome() { return nome; }
    public int getCargaHoraria() { return cargaHoraria; }

    public void adicionarDisciplina(Disciplina disciplina) {
        disciplinas.add(disciplina);
    }

    public void exibirDisciplinas() {
        disciplinas.forEach(d -> System.out.println(d.getNome()));
    }

    public List<Disciplina> getDisciplinas() {
        return disciplinas;
    }
}