// Classe Aluno
package model;

import java.util.*;

public class Aluno extends Pessoa {
    private String ra;
    private List<Curso> cursos = new ArrayList<>();
    private List<Disciplina> disciplinasMatriculadas = new ArrayList<>();

    public Aluno(String nome, int idade, String cpf, String ra) {
        super(nome, idade, cpf);
        this.ra = ra;
    }

    public void matricularCurso(Curso curso) {
        cursos.add(curso);
    }

    public void desmatricularCurso(String nomeCurso) {
        cursos.removeIf(c -> c.getNome().equalsIgnoreCase(nomeCurso));
    }

    public void matricularDisciplina(Disciplina disciplina) {
        disciplinasMatriculadas.add(disciplina);
    }

    public void exibirDisciplinasMatriculadas() {
        disciplinasMatriculadas.forEach(d -> System.out.println(d.getNome()));
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Aluno: " + nome);
        cursos.forEach(c -> System.out.println("Curso: " + c.getNome()));
    }

    public List<Curso> getCursos() {
        return cursos;
    }
}