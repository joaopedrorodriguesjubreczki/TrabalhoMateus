// Classe Disciplina
package model;

public class Disciplina {
    private String nome;
    private int cargaHoraria;
    private int periodo;
    private Curso curso;

    public Disciplina(String nome, int cargaHoraria, int periodo, Curso curso) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.periodo = periodo;
        this.curso = curso;
    }

    public String getNome() { return nome; }
    public Curso getCurso() { return curso; }
}