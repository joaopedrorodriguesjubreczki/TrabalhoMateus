// Classe Professor
package model;

import java.util.*;

public class Professor extends Pessoa {
    private String especialidade;
    private double salario;
    private List<Curso> cursosMinistrados = new ArrayList<>();

    public Professor(String nome, int idade, String cpf, String especialidade, double salario) {
        super(nome, idade, cpf);
        this.especialidade = especialidade;
        this.salario = salario;
    }

    public void atribuirCurso(Curso curso) {
        cursosMinistrados.add(curso);
    }

    public void exibirCursos() {
        cursosMinistrados.forEach(c -> System.out.println(c.getNome()));
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Professor: " + nome);
        System.out.println("Especialidade: " + especialidade);
        System.out.println("Salário: R$ " + salario);
    }
}