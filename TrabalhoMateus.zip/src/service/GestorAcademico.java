// Pacote service
package service;

import model.*;
import java.util.*;
import java.util.stream.Collectors;

public class GestorAcademico {
    private List<Aluno> alunos = new ArrayList<>();
    private List<Professor> professores = new ArrayList<>();
    private Map<String, Curso> cursos = new HashMap<>();

    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public void adicionarProfessor(Professor professor) {
        professores.add(professor);
    }

    public void adicionarCurso(Curso curso) {
        cursos.put(curso.getNome(), curso);
    }

    public List<Aluno> listarAlunosPorCurso(String nomeCurso) {
        return alunos.stream()
            .filter(a -> a.getCursos().stream().anyMatch(c -> c.getNome().equalsIgnoreCase(nomeCurso)))
            .collect(Collectors.toList());
    }

    public long contarAlunosPorCurso(String nomeCurso) {
        return listarAlunosPorCurso(nomeCurso).size();
    }

    public List<Aluno> listarAlunosOrdenados() {
        return alunos.stream().sorted(Comparator.comparing(a -> a.nome)).collect(Collectors.toList());
    }

    public List<Professor> listarProfessoresOrdenados() {
        return professores.stream().sorted(Comparator.comparing(p -> p.nome)).collect(Collectors.toList());
    }

    public Curso buscarCurso(String nome) {
        return cursos.get(nome);
    }
}