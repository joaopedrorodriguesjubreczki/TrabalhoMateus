// Classe principal com menu interativo
import model.*;
import service.GestorAcademico;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        GestorAcademico gestor = new GestorAcademico();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("
1. Criar curso
2. Criar aluno
3. Matricular aluno em curso
4. Exibir alunos por curso
5. Criar disciplina
6. Matricular aluno em disciplina
7. Exibir disciplinas do aluno
8. Sair");
            int op = sc.nextInt();
            sc.nextLine();

            if (op == 8) break;

            switch (op) {
                case 1 -> {
                    System.out.print("Nome do curso: ");
                    String nome = sc.nextLine();
                    System.out.print("Carga horária: ");
                    int carga = sc.nextInt();
                    sc.nextLine();
                    gestor.adicionarCurso(new Curso(nome, carga));
                }
                case 2 -> {
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Idade: ");
                    int idade = sc.nextInt();
                    sc.nextLine();
                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();
                    System.out.print("RA: ");
                    String ra = sc.nextLine();
                    gestor.adicionarAluno(new Aluno(nome, idade, cpf, ra));
                }
                case 3 -> {
                    System.out.print("Nome do aluno: ");
                    String nomeAluno = sc.nextLine();
                    System.out.print("Curso: ");
                    String cursoNome = sc.nextLine();
                    Aluno aluno = gestor.listarAlunosOrdenados().stream().filter(a -> a.nome.equalsIgnoreCase(nomeAluno)).findFirst().orElse(null);
                    Curso curso = gestor.buscarCurso(cursoNome);
                    if (aluno != null && curso != null) aluno.matricularCurso(curso);
                }
                case 4 -> {
                    System.out.print("Curso: ");
                    String cursoNome = sc.nextLine();
                    gestor.listarAlunosPorCurso(cursoNome).forEach(Aluno::exibirDetalhes);
                }
                case 5 -> {
                    System.out.print("Nome da disciplina: ");
                    String nome = sc.nextLine();
                    System.out.print("Carga horária: ");
                    int carga = sc.nextInt();
                    System.out.print("Período: ");
                    int periodo = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Curso: ");
                    String cursoNome = sc.nextLine();
                    Curso curso = gestor.buscarCurso(cursoNome);
                    if (curso != null) curso.adicionarDisciplina(new Disciplina(nome, carga, periodo, curso));
                }
                case 6 -> {
                    System.out.print("Nome do aluno: ");
                    String nomeAluno = sc.nextLine();
                    System.out.print("Nome da disciplina: ");
                    String nomeDisc = sc.nextLine();
                    Aluno aluno = gestor.listarAlunosOrdenados().stream().filter(a -> a.nome.equalsIgnoreCase(nomeAluno)).findFirst().orElse(null);
                    Disciplina disciplina = gestor.buscarCurso(aluno.getCursos().get(0).getNome()).getDisciplinas().stream().filter(d -> d.getNome().equalsIgnoreCase(nomeDisc)).findFirst().orElse(null);
                    if (aluno != null && disciplina != null) aluno.matricularDisciplina(disciplina);
                }
                case 7 -> {
                    System.out.print("Nome do aluno: ");
                    String nomeAluno = sc.nextLine();
                    Aluno aluno = gestor.listarAlunosOrdenados().stream().filter(a -> a.nome.equalsIgnoreCase(nomeAluno)).findFirst().orElse(null);
                    if (aluno != null) aluno.exibirDisciplinasMatriculadas();
                }
            }
        }

        sc.close();
    }
}